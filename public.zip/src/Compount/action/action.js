 export const increace =()=>{

    return {
        type:"increment"
    }

 }
 export const decreacing =()=>{

    return {
        type:"Decriment"
    }

 }